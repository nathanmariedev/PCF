package ast;

public class Lit extends Term {
    public int value;

    public Lit(int value) {
        this.value = value;
    }
}
