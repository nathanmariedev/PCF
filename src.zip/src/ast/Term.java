package ast;

public abstract class Term extends AST {
}
